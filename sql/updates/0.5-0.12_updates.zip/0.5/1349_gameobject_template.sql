ALTER TABLE `gameobject_template`
    DROP KEY `id` ,
    ADD PRIMARY KEY (`entry`) ;
