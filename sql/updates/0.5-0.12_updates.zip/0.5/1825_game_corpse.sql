ALTER TABLE `game_corpse` DROP INDEX `idx_player`;
