ALTER TABLE `item_template` CHANGE `RequiredRaputationRank` `RequiredReputationRank` INT( 30 ) unsigned NOT NULL DEFAULT '0' ;
