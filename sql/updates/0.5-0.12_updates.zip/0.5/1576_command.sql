INSERT INTO `command` VALUES ('additemset',3,'Syntax: .additemset #itemsetid\r\n\r\nAdd items from itemset of id #itemsetid to your inventory. Will add by one example each item from itemset.');
