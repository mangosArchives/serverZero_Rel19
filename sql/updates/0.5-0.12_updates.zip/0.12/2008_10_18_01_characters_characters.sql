ALTER TABLE characters
  CHANGE COLUMN gmstate extra_flags int(11) unsigned NOT NULL default '0';
