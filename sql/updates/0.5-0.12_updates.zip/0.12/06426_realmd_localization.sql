DROP TABLE localization;
