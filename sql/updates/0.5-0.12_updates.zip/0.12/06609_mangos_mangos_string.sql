DELETE FROM mangos_string WHERE entry = 170;
INSERT INTO mangos_string VALUES
(170,'You try to hear sound %u but it doesn\'t exist.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
