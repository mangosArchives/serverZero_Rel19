DELETE FROM mangos_string WHERE entry IN (800);
