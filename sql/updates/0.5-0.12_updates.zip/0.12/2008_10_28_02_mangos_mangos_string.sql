DELETE FROM mangos_string WHERE entry IN (336,337);

INSERT INTO mangos_string VALUES
(336,'You repair all %s''s items.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(337,'All your items repaired by %s.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
