ALTER TABLE `quest_template`
    ADD `RewHonorableKills` INT UNSIGNED NOT NULL AFTER `RewRepValue5`;
