DELETE FROM mangos_string WHERE entry IN (52,53);
INSERT INTO mangos_string VALUES
(52,'Invaid item count (%u) for item %u',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(53,'Mail can\'t have more %u item stacks',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
