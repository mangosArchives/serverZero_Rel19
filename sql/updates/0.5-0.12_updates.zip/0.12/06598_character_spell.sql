ALTER TABLE `character_spell`
    ADD COLUMN `disabled` tinyint(3) unsigned NOT NULL default '0';
