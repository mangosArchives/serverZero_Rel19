DELETE FROM `mangos_string` WHERE entry = 636;
INSERT INTO `mangos_string` VALUES
(636,'The Battle for Eye of the Storm begins in 1 minute.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

DELETE FROM `mangos_string` WHERE entry = 637;
INSERT INTO `mangos_string` VALUES
(637,'The Battle for Eye of the Storm begins in 30 seconds.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);

DELETE FROM `mangos_string` WHERE entry = 638;
INSERT INTO `mangos_string` VALUES
(638,'The Battle for Eye of the Storm has begun!',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
