DELETE FROM mangos_string WHERE entry IN (338,339);

INSERT INTO mangos_string VALUES
(338,'You set waterwalk mode %s for %s.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(339,'Your waterwalk mode %s by %s.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
