DELETE FROM spell_affect WHERE entry = 16824;
