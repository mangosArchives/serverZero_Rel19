ALTER TABLE `character`
    ADD `gmstate` tinyint(3) unsigned NOT NULL default '0';
