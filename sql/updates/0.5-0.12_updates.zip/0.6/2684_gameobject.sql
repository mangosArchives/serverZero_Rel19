alter table gameobject
   add column
  `dynflags` int(11) unsigned NOT NULL default '0';

