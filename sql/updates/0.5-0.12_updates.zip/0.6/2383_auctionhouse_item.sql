DROP TABLE IF EXISTS `auctionhouse_item`;
