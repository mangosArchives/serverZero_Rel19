ALTER TABLE `spell_proc_event`
  CHANGE COLUMN `entry` `entry` smallint(6) unsigned NOT NULL default '0';

