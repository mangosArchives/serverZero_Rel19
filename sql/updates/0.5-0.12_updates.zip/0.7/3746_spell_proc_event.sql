INSERT INTO `spell_proc_event` (`entry` ,`SchoolMask` ,`Category` ,`SkillID` ,`SpellFamilyMask` ,`procFlags` ,`ppmRate`)
VALUES ('27155', '0', '0', '0', '0', '1', '0');