DELETE FROM `spell_proc_event` WHERE `entry` IN ( '27155','27160','27166');
INSERT INTO `spell_proc_event` VALUES
('27155', '0', '0', '0', '0', '1', '0'),
('27160', '0', '0', '0', '0', '1', '5'),
('27166', '0', '0', '0', '0', '1', '5');
