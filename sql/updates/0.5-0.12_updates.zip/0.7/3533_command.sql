UPDATE `command` SET `help` = 'Syntax: .createguild $GuildLeaderName $GuildName\r\n\r\nCreate a guild named $GuildName with the player $GuildLeaderName as leader.' WHERE `name` ='createguild';
