DELETE FROM `command` WHERE `name` = 'learnskill';
DELETE FROM `command` WHERE `name` = 'unlearnskill';
DELETE FROM `command` WHERE `name` = 'fixunlearn';

